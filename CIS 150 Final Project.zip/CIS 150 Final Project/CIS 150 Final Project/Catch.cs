﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIS_150_Final_Project
{
    /// <summary>
    /// Calss:      Catch
    /// Developer:  Jaeyeong Lee
    /// Date:       5/6/2019
    /// Purpose:    maintain info 
    /// </summary>
    class Catch
    {
        // class fields
        private string name;
        private string typeOfFish;
        private int lbs;
        private int oz;
        private string location;

        public string Name { get => name; set => name = value; }
        public string TypeofFish { get => typeOfFish; set => typeOfFish = value; }
        public int Lbs { get => lbs; set => lbs = value; }
        public int Oz { get => oz; set => oz = value; }
        public string Location{ get => location; set => location = value; }
    
        public Catch(string name, string typeOfFish, int lbs, int oz, string location)
        {
            this.name = name;
            this.typeOfFish = typeOfFish;
            this.lbs = lbs;
            this.oz = oz;
            this.location = location;
        }

        public override string ToString()
        {
            string message = "";

            message += $" {name}";
            message += $" {oz}oz";
            message += $" {typeOfFish}";
            message += $" {lbs}lbs";
            message += $" {location}";

            return message;
        }

        public Catch()
        {
        }
    }

}

