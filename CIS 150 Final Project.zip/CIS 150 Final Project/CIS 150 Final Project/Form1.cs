﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CIS_150_Final_Project
{
    /// <summary>
    /// App:
    /// Debeloper:      Jaeyeong Lee
    /// Date:           5/6/2019
    /// Purpose:
    /// </summary>
    public partial class Form1 : Form
    {
        private string fileName;
        private Catch instance;
        private int selectedIndex = -1;

        public Form1()
        {
            InitializeComponent();
        }
        
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
            //Toolbar (File -> open)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("File name chosen: " + openFileDialog1.FileName);
                fileName = saveFileDialog1.FileName;
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
            //Toolbar (File -> save as)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("File Save As Name: " + saveFileDialog1.FileName);
                fileName = openFileDialog1.FileName;
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
            //Toolbat (File -> save)
        {
            saveFileDialog1.FileName = fileName;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("File save name: " + saveFileDialog1.FileName);
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
            // Toolbar (about -> messagebox)
        {
            MessageBox.Show("Today's Catch \n" +
                            "Jaeyeong Lee \n" +
                            "5.6.2019 \n" +
                            "This program is for save information of the fish caught");
        }
        //end of tool bar.


        private void button1_Click(object sender, EventArgs e)
            //Ok button
            // I have data to save
        {
            if (selectedIndex == -1)
            {
                instance = new Catch();

                LoadClassData();

                lstBxCatch.Items.Add(instance);

            }
            else
            {
                instance = (Catch)lstBxCatch.SelectedItem;
                LoadClassData();
                lstBxCatch.Items[selectedIndex] = instance;
            }

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            instance = new Catch();

            LoadFormData();

            lstBxCatch.Items.Add(instance);
        }

        private void LoadClassData()
            // update data with data from textboxes
        {
            instance.Name = txtBxName.Text;
            instance.Location = txtBxLocation.Text;
            instance.TypeofFish = cbBxTypeofFish.Text;
            instance.Lbs = Convert.ToInt32(txtBxlbs.Text);
            instance.Oz = Convert.ToInt32(txtBxoz.Text);
        }

        private void LoadFormData()
        {
            txtBxName.Text = instance.Name;
            txtBxlbs.Text = instance.Lbs.ToString();
            txtBxoz.Text = instance.Oz.ToString();
            txtBxLocation.Text = instance.Location;
            cbBxTypeofFish.Text = instance.TypeofFish;
        }
        private void lstBxCatch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstBxCatch.SelectedIndex != -1)
            {
                selectedIndex = lstBxCatch.SelectedIndex; 

                instance = (Catch) lstBxCatch.SelectedItem; 

                LoadFormData();
            }
        }     
    }
}