﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch_10_Audio_CD_Form102
{
    /// <summary>
    /// App:        Audio Media Maintenance
    /// Developer:  Renee Riley
    /// Date:       4/22/2019
    /// Purpose:    Allow maintenance of Audio Media items
    /// </summary>
    public partial class Form1 : Form
    {
        // class level (instance) variable
        private AudioCd instanceCd;
        private int selectedIndex = -1;     
        /// <summary>
        /// Form1 constructor - default no-arg constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// this event procedure will handle adding and updating media instances
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOk_Click(object sender, EventArgs e)
        {
            // we have audio data to save
            // create an empty audio cd instance to save the data
            if (selectedIndex == -1)
            {
                instanceCd = new AudioCd();

                LoadClassData();

                txtBxStatus.Text = "Item added ...";

                lstBxItems.Items.Add(instanceCd);

                ResetForm();
            }
            else
            {
                instanceCd = (AudioCd) lstBxItems.SelectedItem;
                LoadClassData();
                lstBxItems.Items[selectedIndex] = instanceCd;
                txtBxStatus.Text = "Item updated ...";
            }
        }

        private void LoadClassData()
        {
            // update audio cd data with data from textboxes
            instanceCd.Id = txtBxId.Text;
            instanceCd.Artist = txtBxArtist.Text;
            instanceCd.Name = txtBxName.Text;
            instanceCd.NumTracks = Convert.ToInt32(txtBxNumTracks.Text);
            instanceCd.Qty = Convert.ToInt32(txtBxQty.Text);
            instanceCd.Cost = Convert.ToDecimal(txtBxCost.Text);
        }

        //private void txtBxNumTracks_TextChanged(object sender, EventArgs e)
        //{
        //    int temp;
        //    if (int.TryParse(txtBxNumTracks.Text, out temp))
        //        // what should i do?
        //}
        /// <summary>
        /// this event procedure validates input as numeric
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtBxQty_TextChanged(object sender, EventArgs e)
        {
            string tString = txtBxQty.Text;

            if (tString.Trim() == "") return;
            for (int i = 0; i < tString.Length; i++)
            {
                if (!char.IsNumber(tString[i]))
                {
                    //MessageBox.Show("Please enter a valid number");
                    txtBxStatus.Text = "Please enter a valid quantity";
                    txtBxQty.Text = "";
                    txtBxQty.Focus();
                    //return;
                }

            }
        }
        /// <summary>
        /// this event procedure will validate the input as numeric
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtBxCost_TextChanged(object sender, EventArgs e)
        {
            string tString = txtBxCost.Text;
            if (tString.Trim() == "") return;
            for (int i = 0; i < tString.Length; i++)
            {
                if (!(char.IsNumber(tString[i]) || (tString[i] == '.')))
                {
                    txtBxStatus.Text = "Invalid cost amount";
                    //MessageBox.Show("Invalid cost amount");
                    txtBxCost.Text = "";
                    txtBxCost.Focus();
                }

            }
        }
        /// <summary>
        /// this event procedure will validate the input as numeric
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtBxNumTracks_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        /// <summary>
        /// this event procedure will reset the display
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();

            txtBxStatus.Text = "Ready to add ...";
            selectedIndex = -1;
        }
        /// <summary>
        /// this method clears the form data
        /// </summary>
        private void ResetForm()
        {
            // clear out the form controls
            txtBxId.Text = "";
            txtBxArtist.Text = "";
            txtBxName.Text = "";
            txtBxNumTracks.Text = "";
            txtBxQty.Text = "";
            txtBxCost.Text = "";

            txtBxId.Focus();
        }
        /// <summary>
        /// this event procedure will execute to prepare the form for display
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            // create a default audio cd instance
            instanceCd = new AudioCd();

            LoadFormData();

            txtBxStatus.Text = "Default data loaded ...";

            lstBxItems.Items.Add(instanceCd);

        }

        private void LoadFormData()
        {
            txtBxId.Text = instanceCd.Id;
            txtBxName.Text = instanceCd.Name;
            txtBxArtist.Text = instanceCd.Artist;
            txtBxQty.Text = instanceCd.Qty.ToString();
            txtBxNumTracks.Text = instanceCd.NumTracks.ToString();
            txtBxCost.Text = instanceCd.Cost.ToString();
        }

        private void lstBxItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstBxItems.SelectedIndex != -1)
            {
                selectedIndex = lstBxItems.SelectedIndex; //save the index

                instanceCd = (AudioCd) lstBxItems.SelectedItem; //get the data

                LoadFormData();

                txtBxStatus.Text = "Audio data loaded ...";
            }
        }

        private void txtBxArtist_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
