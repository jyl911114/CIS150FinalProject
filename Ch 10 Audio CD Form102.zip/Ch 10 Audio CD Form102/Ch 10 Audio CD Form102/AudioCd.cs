﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch_10_Audio_CD_Form102
{
    /// <summary>
    /// Class:      AudioCD
    /// Developer:  Renee Riley
    /// Date:       2/25/2019
    /// Purpose:    maintain info about an audio cd
    /// </summary>
    class AudioCd
    {
        // class fields
        // instance variable (variable unique data for ea instance)
        // global to our class
        // always private; names start with lowercase letters
        private string id;
        private string name;
        private string artist;
        private int numTracks;
        private decimal cost;
        private int qty;

        public string Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Artist { get => artist; set => artist = value; }
        public int NumTracks { get => numTracks; set => numTracks = value; }
        public decimal Cost { get => cost; set => cost = value; }
        public int Qty { get => qty; set => qty = value; }

        // construct an instance with a constructor
        // a constructor is a special type of method 
        // with no return type
        public AudioCd(string id, string name, string artist, int noTracks,
            decimal cost, int qty)
        {
            this.id = id;
            this.name = name;
            this.artist = artist;
            this.numTracks = noTracks;
            this.cost = cost;
            this.qty = qty;
        }
        // no-arg constructor
        public AudioCd()
        {
            id = "ff";
            name = "default CD name";
            artist = "default artist";
            numTracks = 99;
            cost = 0;
            qty = 0;
        }
        /// <summary>
        /// this method outputs audio cd info
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="album"></param>
        /// <param name="numTracks"></param>
        /// <param name="cost"></param>
        /// <param name="cdValue"></param>
        public override string ToString()
        {
            string message = "";
            // interpolated string 
            message += $" {id}";
            message += $" {name}";
            message += $" {artist}";
            message += $" {numTracks}";
            message += $" {cost:c}";

            //message += $"\ncd value  : {cdValue:c}";

            return message;
        }

        public string LongString()
        {
            string message = "";
            // interpolated string 
            message += $"\nId        : {id}";
            message += $"\nalbum     : {name}";
            message += $"\nartist    : {artist}";
            message += $"\nnum tracks: {numTracks}";
            message += $"\ncost      : {cost:c}";
            //message += $"\ncd value  : {cdValue:c}";

            return message;
        }
        /// <summary>
        /// static method that calculates value
        /// </summary>
        /// <param name="cost"></param>
        /// <param name="numTracks"></param>
        /// <returns></returns>
        /// public = access mode
        /// static = other keyword - means the method will be in memory only once
        /// decimal = data return type
        /// CalcValue = name of the method (identifier)
        /// ( = beginning of parameter list
        /// decimal = data type of the first parameter
        /// cost = first parameter identifier (variable name)
        /// , = indicates param list continues
        /// int = data type of next param
        /// numTracks = identifier of next param (variable name)
        ///  ) = end of parameter list
        public static decimal CalcValue(decimal cost, int numTracks)
        {
            return (cost * (numTracks * .2m));
        }
    }
}